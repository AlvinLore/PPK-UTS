package com.polstat.pendaftaranukm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PendaftaranukmApplication {

	public static void main(String[] args) {
		SpringApplication.run(PendaftaranukmApplication.class, args);
	}

}
