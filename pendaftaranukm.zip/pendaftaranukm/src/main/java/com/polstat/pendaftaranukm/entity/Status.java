package com.polstat.pendaftaranukm.entity;

public enum Status {
    PENDING,
    APPROVED,
    REJECTED
}
