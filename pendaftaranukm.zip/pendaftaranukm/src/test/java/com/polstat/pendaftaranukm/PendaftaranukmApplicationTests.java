package com.polstat.pendaftaranukm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PendaftaranukmApplicationTests {

	@Test
	void contextLoads() {
	}

}
